---
layout: post
title:  "jekyll을 이용한 블로그 개설"
date:   2019-04-24 01:05:00
categories: diary
tags: jekyll markdown HTML CSS
author: Yo_EE
mathjax: true
---
깃헙으로 블로그를 만들고자 하는 열망을 갖고

구글링을 해서 새로운 repository를 파고 jekyll을 활용해 만들었습니다.


reference

[쉽고 빠르게 수준 급의 GitHub 블로그 만들기 - jekyll remote theme으로](https://dreamgonfly.github.io/2018/01/27/jekyll-remote-theme.html)

[gaohaoyang.github.io](https://github.com/Gaohaoyang/gaohaoyang.github.io)
