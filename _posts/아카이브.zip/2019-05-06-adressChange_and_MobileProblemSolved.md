---
layout: post
title:  "깃 블로그 주소 변경 및 뜬금 없는 문제 해결"
date:   2019-05-06 23:41:00
categories: diary
tags: blog diary HTML
author: Yo_EE
mathjax: true
---
고민을 하다가 그냥 블로그 주소를 바꿔버렸다.

Seoyongsam.github.io/blog 에서 Seoyongsam.github.io 로. 그냥 뒤에 /blog를 빼버리고 그러기 위해서 파일 몇 가지를 수정했다.

오잉 그랬더니 모바일 메뉴가 해결이 됐네? (모바일 웹에서 우측 상단의 메뉴가 안 먹혔다. 그게 해결됨)

그냥 애초부터 이렇게 할 걸 하는 생각?
