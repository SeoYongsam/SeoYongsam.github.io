---
layout: post
title:  "Problem Solving에 관심을 갖게 되다"
date:   2019-04-25 15:05:00
categories: ProblemSolving
tags: ProblemSolving Book SQL Coding
author: Yo_EE
mathjax: true
---
# 종만북 구입 외
종만북이라고 불리는 **알고리즘 문제해결전략** 책을 오늘 점심에 교보문고에서 구입했다. 살지 말지 고민을 참 많이 했는데 예전엔 비싸서 안샀다. 오늘 산 건 물론 어느정도의 충동구매이기도 했지만 예전부터 눈여겨보던 책이기도 했기에...

사기 전에 열심히 핸드폰으로 구글링해서 Problem Solving을 막 홀린 듯이 찾아봤다. 그 찾아본 링크들 모아뒀다..

* [알고리즘 공부, 어떻게 해야하나요?](https://baactree.tistory.com/52)
* [plzrun’s algorithm :: 알고리즘 문제풀이(PS) 시작하기](https://plzrun.tistory.com/entry/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98-%EB%AC%B8%EC%A0%9C%ED%92%80%EC%9D%B4PS-%EC%8B%9C%EC%9E%91%ED%95%98%EA%B8%B0)
* [알고리즘 교재 추천](https://jellybinn.tistory.com/m/1)
* [내가 한 컴퓨터 공부들과 공부 방법 등.](https://qkqhxla1.tistory.com/m/802)

---
뜬금없게도 컴퓨터 그래픽스 운용기능사 필기 책인 ‘2019 이기적 컴퓨터그래픽스운용기능사 필기 미니족보’ 에도 관심이 생겼었었지만, 충동구매에 공부를 안 할 것 같아 사진 않았다. 책은 깔쌈하게 잘 나온 것 같았는데.

---
SQLD라는 SQL 자격증에도 관심이 생겼다. 데이터캠프에서 SQL 관련 강의를 들어서 눈이 살짝 갔나보다. 하지만 데이터캠프에서 R만 해도 갈 길이 먼 것 같으므로 일단 마음속에만 콩찜하기.
‘SQL 자격검정 실전문제’
* [SQLD 자격증 준비 및 합격 후기 (준비 자료 첨부)](https://goddaehee.tistory.com/m/71)
