---
layout: post
title:  "음대 오케스트라 공연 감상"
date:   2019-04-25 22:15:00
categories: diary
tags: music orchestra diary culture
author: Yo_EE
mathjax: true
---
# 음대 오케스트라
스누포 최적화된 공연. 1부에 서곡이 4개나 있었고, 2부에는 교향곡 드보르작 8번이 있었다. 1부 곡들을 들을 때는 집중력이 또렷했는데 2부때는 좀 피곤했다.

이틀 연속으로 문화생활을 해서 뿌듯하다. 시험기간이라서 더...
